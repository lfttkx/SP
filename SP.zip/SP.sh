#!/bin/bash
if [[ -d "/sdcard/Download/SP" ]]; then
echo ""
else
mkdir /sdcard/Download/SP
fi
if [[ -d "/sdcard/Download/SP/Paks" ]]; then
echo ""
else
mkdir /sdcard/Download/SP/Paks
fi
if [[ -d "/sdcard/Download/SP/解包" ]]; then
echo ""
else
mkdir /sdcard/Download/SP/解包
fi
if [[ -d "/sdcard/Download/SP/打包" ]]; then
echo ""
else
mkdir /sdcard/Download/SP/打包
fi
if [[ -d "/sdcard/Download/SP/解包2" ]]; then
echo ""
else
mkdir /sdcard/Download/SP/解包2
fi
if [[ -d "/sdcard/Download/SP/打包2" ]]; then
echo ""
else
mkdir /sdcard/Download/SP/打包2
fi
if [[ -d "/sdcard/Download/SP/非块打包" ]]; then
echo ""
else
mkdir /sdcard/Download/SP/非块打包
fi
if [[ -d "/sdcard/Download/SP/非块解包" ]]; then
echo ""
else
mkdir /sdcard/Download/SP/非块解包
fi
if [[ -d "/sdcard/Download/SP/块解包" ]]; then
echo ""
else
mkdir /sdcard/Download/SP/块解包
fi
if [[ -d "/sdcard/Download/SP/块分割" ]]; then
echo ""
else
mkdir /sdcard/Download/SP/块分割
fi
clear
chmod +x SP1/quickbms
packages=("wget" "unzip" "zip" "curl" "rsync" "x11-repo" "pv" "figlet" "toilet"  "qemu-system-i386" "qemu-user-i386")
for pkg in ${packages[@]}; do
is_pkg_installed=$(dpkg-query -W --showformat='${Status}
' ${pkg} | grep "install ok installed")
if [ "${is_pkg_installed}" == "install ok installed" ]; then
echo -e ${LGREEN}${pkg}${NC} is installed.
else [ "" = "${is_pkg_installed}" ];
echo -e "${LRED}No ${pkg}. Setting up ${pkg}.${NC}"
pkg install ${pkg} -y
fi
done
chmod +x SP1/hpmh
chmod +x SP1/pubgmh
chmod +x SP1/tq
if [ -f $HOME/SP/SP ]; then
chmod +x $HOME/SP/SP
mv $HOME/SP/SP $PREFIX/bin
fi
function zl {
if [ -f $HOME/SP/SP ]; then
chmod +x SP
./SP
fi
}
zl
